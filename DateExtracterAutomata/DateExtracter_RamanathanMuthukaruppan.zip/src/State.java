import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class State {
	private boolean initialState;
	private boolean finalState;
	private HashMap<String, State> transitionTable;
	
	public State(boolean initialState, boolean finalState, HashMap<String, State> transitionTable){
		this.initialState = initialState;
		this.finalState = finalState;
		if(transitionTable == null){
			this.transitionTable = new HashMap<String, State>();
		}
		else{
			this.transitionTable = transitionTable;
		}
	}
	
	public State getNextState(String input){
		Iterator iterator = transitionTable.entrySet().iterator();
		while(iterator.hasNext()){
			Map.Entry<String, State> transition = (Map.Entry<String, State>)iterator.next();
			Pattern pattern = Pattern.compile(transition.getKey(), Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(input); 
			if(matcher.find()){
				//System.out.println(input + " " + transition.getKey());
				return transition.getValue();
			}
		}
		return null;
	}
	
	public boolean isFinalState(){
		return finalState;
	}
	
	public boolean isInitialState(){
		return initialState;
	}

	public void setFinalState(){
		finalState = true;
	}
	
	public void setInitialState(){
		initialState = true;
	}
	
	public void addToTransitionTable(String input, State state) {
	    // TODO Auto-generated method stub
		//input corresponds to the regex pattern
	    transitionTable.put(input, state);
    }
}
