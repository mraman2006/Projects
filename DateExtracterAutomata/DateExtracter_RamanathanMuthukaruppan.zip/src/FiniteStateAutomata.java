import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Scanner;


public class FiniteStateAutomata {
	ArrayList<State> setOfStates;
	State currentState;
	
	public FiniteStateAutomata(int noOfStates){
		setOfStates = new ArrayList<State>();
		for(int i=0; i<noOfStates; i++){
			setOfStates.add(new State(false, false, null));
		}
	}
	
	public void createTransitionTable(ArrayList<String> automataStructure){
		ListIterator<String> iterator = automataStructure.listIterator(3);
		while(iterator.hasNext()){
			String stateSequence = iterator.next();
			Scanner scanner = new Scanner(stateSequence);
			//System.out.println(stateSequence);
			int state1 = scanner.nextInt();
			String input = scanner.next();
			int state2 = scanner.nextInt();
			setOfStates.get(state1).addToTransitionTable(input, setOfStates.get(state2));
		}
	}
	
	public void createInitialStates(String setOfInitialStates){
		Scanner scanner = new Scanner(setOfInitialStates);
		while(scanner.hasNext()){
			State s = setOfStates.get(scanner.nextInt());
			s.setInitialState();
			currentState = s;
		}
	}

	public void createFinalStates(String setOfFinalStates){
		Scanner scanner = new Scanner(setOfFinalStates);
		while(scanner.hasNext()){
			State s = setOfStates.get(scanner.nextInt());
			s.setFinalState();
		}

	}
	
	public ArrayList<String> executeAutomata(List<String> tokens){
		ArrayList<String> q = new ArrayList<String>();
		ArrayList<String> extractedDates = new ArrayList<String>();
		ListIterator<String> iterator = tokens.listIterator();
		String token = iterator.next();
		while(iterator.hasNext()){
			State nextState = currentState.getNextState(token);
			if(nextState == null){
				if(q.isEmpty()){
					token = iterator.next();
				}
				q.clear();
				currentState = setOfStates.get(0);
			}
			else{
				q.add(token);
				if(nextState.isFinalState()){
					CustomHelper helper = new CustomHelper();
					String extractedDate = helper.joinArrayList(q, " ");
					extractedDates.add(extractedDate);
				}
				token = iterator.next();
				currentState = nextState;
			}
		}
		return extractedDates;
	}
}
