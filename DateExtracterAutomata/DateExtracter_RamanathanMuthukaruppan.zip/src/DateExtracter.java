import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;


public class DateExtracter {
	public static void main(String args[]){
		CustomFileHelper file = new CustomFileHelper("dictionary.txt");
		ArrayList<String> automataStructure = file.getFileContents();
		ListIterator<String> iterator = automataStructure.listIterator();
		int noOfStates = Integer.parseInt(iterator.next());
		String setOfInitialStates = iterator.next();
		String setOfFinalStates = iterator.next();
		
		FiniteStateAutomata fsa = new FiniteStateAutomata(noOfStates);
		fsa.createTransitionTable(automataStructure);
		fsa.createInitialStates(setOfInitialStates);
		fsa.createFinalStates(setOfFinalStates);

		CustomFileHelper inputFile = new CustomFileHelper(args[0]);
		ArrayList<String> contents = inputFile.getFileContents();
		String content = inputFile.concatenateFileContents(contents);
		String[] tokens = content.split("\\s+|\\.|,");
		List<String> tokensList = Arrays.asList(tokens);
		ArrayList<String> extractedDates = fsa.executeAutomata(tokensList);
		//System.out.println(extractedDates);
		
		CustomFileHelper writeFile = new CustomFileHelper("output.txt");
		writeFile.writeArrayListToFile(extractedDates);
	}
}
